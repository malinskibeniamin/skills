import {chromium} from '@playwright/test';
const browser=await chromium.launch();
try {
 for (const [name,port] of [['after',19367]] as const) {
  const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1,locale:'en-US'});
  await page.goto(`http://127.0.0.1:${port}`); await page.locator('.xterm-screen').click();
  await page.keyboard.type('review-gates --help',{delay:40}); await page.keyboard.press('Enter');
  await page.waitForFunction(()=>Array.from({length:window.term.buffer.active.length},(_,i)=>window.term.buffer.active.getLine(i).translateToString()).some(s=>s.includes('Usage:')||s.includes('Module not found')));
  await page.keyboard.type('review-gates check',{delay:40}); await page.keyboard.press('Enter');
  await page.waitForFunction(()=>Array.from({length:window.term.buffer.active.length},(_,i)=>window.term.buffer.active.getLine(i).translateToString()).some(s=>s.includes('CLI exit:')));
  await page.mouse.move(1150,650); await page.screenshot({path:`.context/rebase-latest-evidence/${name}.png`});
  await page.close();
 }
} finally {await browser.close();}
