import {createRequire} from 'node:module';
import {resolve} from 'node:path';
const app=createRequire(resolve('docs-site/package.json'));const blume=createRequire(app.resolve('blume/package.json'));const {marked}=await import(blume.resolve('marked'));
const file='.context/rebase-latest-evidence/actual-inline-receipts.html'; const html=await Bun.file(file).text();
await Bun.write(file,html.slice(0,html.indexOf('<!-- harness-review:start -->'))+await marked.parse(await Bun.file('.context/review-passed.md').text(),{gfm:true})+'</html>');
