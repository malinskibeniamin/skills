<!-- harness-review:start -->
## Review gates

Review status: blocked

Candidate: 03cf91fd10736aa9bbf06c9dec2f5b9def17863d; base: 03cf91fd10736aa9bbf06c9dec2f5b9def17863d.
Review input: f8d3db8cddf37049640ec2879eec6e4176f9c40135c735f800e7de4f5d712aa5 (full diff plus captured working changes).

| Gate | Executor | Status | Reason / evidence |
|---|---|---|---|
| Correctness | inline: fixture-inline (not recorded) | ❌ Needs changes | P1 README.md:1: Synthetic visual fixture, not a real review result. |
| Value and claims | Not run | ⏳ Not run | Required on every change |
| Test integrity | Not run | ⏳ Not run | Semantic applicability: New public-seam regression and integration tests |
| Security and recovery | Not run | ⏳ Not run | Semantic applicability: Untrusted reviewer JSON, staging paths, immutable inputs, safe report projection and atomic recovery |
| Contracts and architecture | Not run | ⏳ Not run | Semantic applicability: One canonical findings contract now feeds hooks and candidate-bound gate records |
| Surface review | Not run | ⏳ Not run | Semantic applicability: New CLI output and rendered PR table with pending, error and stale states |
| Dependencies and licenses | Not run | ⏳ Not run | Semantic applicability: Package scripts changed; verify no dependency or license churn |
| Documentation | Not run | ⏳ Not run | Path signal: README.md |
| Performance | Not run | ➖ Skipped | Semantic applicability: No speedup, throughput or resource-saving claim; no benchmark or application hot path changed |
| Operations | Not run | ⏳ Not run | Semantic applicability: Review collection and optional hosted-readiness behavior changed |

Agent and inline results are not human approval or merge authorization.
<!-- harness-review:end -->
