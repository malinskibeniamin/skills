import {test,expect} from '@playwright/test';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
for(const name of ['pending','error','needs-changes','passed','notes','stale','actual-inline-receipts']){
 for(const width of [1360,640]){
  test(`${name} output at ${width}px`,async({page})=>{
   await page.setViewportSize({width,height:1000});
   await page.setContent(readFileSync(join(import.meta.dirname,`${name}.html`),'utf8'));
   await page.evaluate(()=>document.fonts.ready);
   await expect(page.getByRole('heading',{name:'Review gates'})).toBeVisible();
   await expect(page.locator('tbody tr')).toHaveCount(10);
   await expect(page.locator('th')).toHaveCount(4);
   await expect(page.locator('img,script,[onerror],[onclick]')).toHaveCount(0);
   for(const link of await page.locator('a').all()){await expect(link).toHaveText(/^https:\/\/example\.invalid/);await expect(link).toHaveAttribute('href',/^https:\/\/example\.invalid/);}
   expect(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)).toBe(false);
   await expect(page).toHaveScreenshot(`${name}-${width}.png`,{fullPage:true,animations:'disabled'});
  });
 }
}
