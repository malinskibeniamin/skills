# Affected surfaces and visual evidence

Baseline: a1210e0ace81f95ddca7cd2fade5ab70f8052656.
Candidate: 800fe2588af39cd1c492c9eb9d10f6638ede2e73.

| Surface / state | Verification | Capture |
|---|---|---|
| New CLI help and check / passed | Real commands on archived base and current candidate; same flow, Chromium 1280x720, ttyd browser terminal, 15px monospace, en-US | before/after video and terminal PNGs |
| New Markdown gate report / passed, skipped, pending, invalid/error, stale, needs changes, notes | Real CLI render; existing 17 public-seam tests; Playwright screenshot assertions at 1360px and 640px | Explicit New view; base had no report command; report PNGs |
| Hook messages / malformed enums, reasoned skip, contradictory approval | Actual hook invocation in existing Bun regression tests, 620-test hook suite | Output evidence, not a graphical interaction; CLI video is primary terminal capture |
| Optional readiness JSON / not-configured, missing, mismatched, passed | Existing full-send-check public CLI tests | Machine-readable API; no separate layout |
| README, GLOSSARY, workflow references and review schema | Source Markdown and docs checks; no canonical SKILL changes, generated skill pages unchanged | No custom renderer changed; report renderer captures cover new table formatting |

No application routes, themes, user roles, forms, focus styling, responsive components or loading animations changed. Terminal and report use keyboard flow; not an interactive browser application. Narrow report layout tested for wrapping. No fixture is presented as historical product UI. Output status fixtures are labeled synthetic consumers; current passing report uses actual inline receipts. Browser terminal uses localhost only and is closed after evidence collection. Video is actual keystrokes and command execution, not animation of screenshots. No speed, defect-detection, independence, human-approval or merge-readiness claim.

Snapshot updates are limited to these newly added disposable evidence cases. Existing functional source tests remain committed; evidence tests/snapshots are included in the attached evidence archive rather than adding a new runtime dependency or CI platform to this PR.

## Rebase scope

Preserved upstream native jq validation, versioned reviewer reports and mutation-isolation
instructions. Gate receipts call that contract, reject contradictory approvals and keep
unavailable/failed coverage non-passing. Fresh terminal images/video are exact base/candidate;
14 updated screenshots were inspected and then passed normally. Ten synthetic-state images
change only revision/input metadata; two error images show the new strict contract diagnostic;
two actual-receipt images show current 217-test evidence and new contract integration.
No tolerances, masks, production guards or assertions were relaxed.
