import {writeFileSync}from'node:fs';
const elements:object[]=[];
function text(id:string,x:number,y:number,w:number,h:number,value:string,size=18){elements.push({id,type:'text',x,y,width:w,height:h,angle:0,strokeColor:'#1e293b',backgroundColor:'transparent',fillStyle:'solid',strokeWidth:1,strokeStyle:'solid',roughness:0,opacity:100,groupIds:[],frameId:null,roundness:null,seed:100,version:1,versionNonce:1,isDeleted:false,boundElements:null,updated:1,link:null,locked:false,text:value,originalText:value,fontSize:size,fontFamily:2,textAlign:'center',verticalAlign:'top',containerId:null,lineHeight:1.25,autoResize:false});}
function box(id:string,x:number,y:number,label:string,color:string){elements.push({id,type:'rectangle',x,y,width:300,height:75,angle:0,strokeColor:'#475569',backgroundColor:color,fillStyle:'solid',strokeWidth:1,strokeStyle:'solid',roughness:0,opacity:100,groupIds:[],frameId:null,roundness:{type:3},seed:100,version:1,versionNonce:1,isDeleted:false,boundElements:[],updated:1,link:null,locked:false});text(id+'-label',x+10,y+14,280,48,label);}
function arrow(id:string,x:number,y:number,height:number){elements.push({id,type:'arrow',x,y,width:0,height,angle:0,points:[[0,0],[0,height]],strokeColor:'#64748b',backgroundColor:'transparent',fillStyle:'solid',strokeWidth:2,strokeStyle:'solid',roughness:0,opacity:100,groupIds:[],frameId:null,roundness:null,seed:100,version:1,versionNonce:1,isDeleted:false,boundElements:[],updated:1,link:null,locked:false,startBinding:null,endBinding:null,startArrowhead:null,endArrowhead:'arrow'});}
text('title',20,20,810,35,'Review evidence and readiness',26);
text('before-title',20,80,380,30,'Previous · 4a7f3bf5fd2a',22);
text('after-title',450,80,380,30,'New · ac5f343b8898',22);
box('old-json',60,140,'Reviewer JSON','#f1f5f9');arrow('old-1',210,220,25);
box('old-collection',60,250,'Native version 1 jq checks\n+ session append','#f1f5f9');
box('old-readiness',60,470,'Hosted readiness\n(no gate evidence checkpoint)','#f1f5f9');
text('old-note',30,355,360,70,'No candidate-bound gate plan\nor generated gate table',18);
box('new-json',490,140,'Reviewer JSON','#f1f5f9');arrow('new-1',640,220,25);
box('new-validator',490,250,'Existing jq contract\n+ typed gate receipts','#dbeafe');arrow('new-2',640,330,25);
box('new-records',490,360,'Immutable candidate snapshot\n+ per-gate results','#dbeafe');arrow('new-3',640,440,25);
box('new-checkpoint',490,470,'One review checkpoint\n→ PR table + opt-in readiness','#dcfce7');
text('note',20,590,810,55,'Original inline implementation. No agent dispatch or publication.\nAgent results are not human approval or merge authorization.',16);
writeFileSync('.context/rebase-latest-evidence/architecture.excalidraw',JSON.stringify({type:'excalidraw',version:2,source:'https://excalidraw.com',elements,appState:{viewBackgroundColor:'#ffffff'},files:{}},null,2));
