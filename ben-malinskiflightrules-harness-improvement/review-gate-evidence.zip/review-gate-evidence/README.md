# Review gate rebase evidence

Candidate: 8d621d249e97a3505e7e6ab490f4894d4b1065a3
Base: c291e60c869ea0a69926c06434d38c0ff0ac15f6

The native hook and adversarial reviewer remain exactly as on main. Gate collection uses
the existing version 1 jq contract, with a gate adapter for ids/provenance and sufficiency.
Native incomplete states cannot become passing gate evidence. New gate regression was
observed RED (schema version 2 accepted) then GREEN; all 217 Bun tests pass, as do 620 hook
checks (4 existing skips), 38 reviewer-contract cases, 24 hook evals, quality/docs/generation.
Video-fixture evals passed 29 checks before the second rebase; video executable/fixture
content did not change in that rebase. Fresh hosted CI provides clean-checkout full evidence.

inventory.md covers every affected surface. before.png / after.png and the native video
are real terminal commands on the exact revisions; flow.txt contains the actual keyboard
interactions. Report HTML is a local Markdown preview, not hosted GitHub UI. Synthetic
states are labeled; actual-inline-receipts uses current inline evidence. All 14 screenshot
assertions passed without update flags after intentional snapshot review. To replay from
this directory in a matching checkout: bunx --no-install playwright test --config
.context/rebase-latest-evidence/playwright.config.ts. Renderer/style and tolerances unchanged.

Logs have local checkout/scratch paths redacted; no credentials are included. No live
reviewer agent, independent model trial, hosted playback or human approval is claimed.
No new source branch, PR, scheduler or production-service change.

Final integration repair: canonical gate-mode validation derives critical-check failure.
A P2 finding, model-provided false flag and unrelated finding refutation cannot clear it.
The public CLI regression was observed RED then GREEN. Final source commit 8d621d24;
all 217 tests and quality/docs checks rerun. Native contract mode remains unchanged.

Final rebase onto c291e60c: range-diff preserves all three patches exactly. Fresh 217-test, lint/type/format/docs and translation replay passed. Gate receipts, 14 screenshot cases and real terminal/video were refreshed on 8d621d24.
