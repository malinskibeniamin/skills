# Affected surfaces and visual evidence

Baseline: 61d68abd5f06ed8b4fc7234c9fb3faae2ebf93c5.
Candidate: 7965c55f324b59b34f6bb4d8cec07e5e6df7de41.

| Surface / state | Verification | Capture |
|---|---|---|
| New CLI help and check / passed | Real commands on detached base and current candidate; same flow, Chromium 1280x720, ttyd browser terminal, 18px monospace, en-US | before/after video and terminal PNGs |
| New Markdown gate report / passed, skipped, pending, invalid/error, stale, needs changes, notes | Real CLI render; existing 16 public-seam tests; Playwright screenshot assertions at 1360px and 640px | Explicit New view; base had no report command; report PNGs |
| Hook messages / malformed enums, reasoned skip, contradictory approval | Actual hook invocation in existing Bun regression tests, 620-test hook suite | Output evidence, not a graphical interaction; CLI video is primary terminal capture |
| Optional readiness JSON / not-configured, missing, mismatched, passed | Existing full-send-check public CLI tests | Machine-readable API; no separate layout |
| README, GLOSSARY, workflow references and review schema | Source Markdown and docs checks; no canonical SKILL changes, generated skill pages unchanged | No custom renderer changed; report renderer captures cover new table formatting |

No application routes, themes, user roles, forms, focus styling, responsive components or loading animations changed. Terminal and report use keyboard flow; not an interactive browser application. Narrow report layout tested for wrapping. No fixture is presented as historical product UI. Output status fixtures are labeled synthetic consumers; current passing report uses actual inline receipts. Browser terminal uses localhost only and is closed after evidence collection. Video is actual keystrokes and command execution, not animation of screenshots. No speed, defect-detection, independence, human-approval or merge-readiness claim.

Snapshot updates are limited to these newly added disposable evidence cases. Existing functional source tests remain committed; evidence tests/snapshots are included in the attached evidence archive rather than adding a new runtime dependency or CI platform to this PR.

## CI follow-up scope

Only evals/test-hooks.sh and evals/test-pr-video.sh change after the rebase. Their fixtures now follow the unchanged production contracts, and the failure-path assertion checks the actual step diagnostic. No new application surface is introduced by this correction. Current screenshots/video/receipts were refreshed for the new revision and base; changes to the captured report are revision metadata and updated test evidence only. Detached baseline was removed after capture to avoid contaminating broad source-document scans.
