<!-- harness-review:start -->
## Review gates

Review status: stale

Candidate: 03cf91fd10736aa9bbf06c9dec2f5b9def17863d; base: 03cf91fd10736aa9bbf06c9dec2f5b9def17863d.
Review input: caf0477e8674924c63d1e782677922538bbe47c7986337eb09f66f0fcd768547 (full diff plus captured working changes).

| Gate | Executor | Status | Reason / evidence |
|---|---|---|---|
| Correctness | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Value and claims | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Test integrity | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Security and recovery | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Contracts and architecture | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Surface review | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Dependencies and licenses | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Documentation | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Performance | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |
| Operations | Not run | ⚠️ Stale | Candidate, working changes or rubric inputs changed; re-plan and review |

Agent and inline results are not human approval or merge authorization.
<!-- harness-review:end -->
