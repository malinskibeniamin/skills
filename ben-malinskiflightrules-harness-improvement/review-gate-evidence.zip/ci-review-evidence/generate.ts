import {mkdirSync,writeFileSync,readFileSync,existsSync,unlinkSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createRequire} from 'node:module';
const directory=resolve('.context/ci-review-evidence');
const root=join(directory,'consumer'); mkdirSync(root,{recursive:true});
const run=(cmd:string[],cwd=root)=>{const r=Bun.spawnSync(cmd,{cwd,env:{...Bun.env,GIT_AUTHOR_DATE:'2026-01-01T00:00:00Z',GIT_COMMITTER_DATE:'2026-01-01T00:00:00Z'}});return {code:r.exitCode,text:r.stdout.toString(),error:r.stderr.toString()};};
const git=(...args:string[])=>{const r=run(['git',...args]);if(r.code)throw Error(r.error);return r.text.trim()};
const cli=(...args:string[])=>run([process.execPath,'--no-install',resolve('scripts/review-gates.ts'),...args]);
if(!existsSync(join(root,'.git'))){git('init','-b','main');git('config','user.name','Visual evidence fixture');git('config','user.email','fixture@example.invalid');writeFileSync(join(root,'.gitignore'),'.context/\n');writeFileSync(join(root,'README.md'),'Baseline\n');git('add','.');git('commit','-m','test(review): fixture baseline');writeFileSync(join(root,'README.md'),'Candidate\n');}
mkdirSync(join(root,'.context'),{recursive:true});
writeFileSync(join(root,'.context/classifications.json'),readFileSync('.context/review-classifications.json'));
const planned=cli('plan','--base','main','--classifications','.context/classifications.json');if(planned.code)throw Error(planned.error);const plan=JSON.parse(planned.text);
const reports:Record<string,string>={};
const capture=(state:string,code:number)=>{const check=cli('check');if(check.code!==code)throw Error(`${state}: ${check.text} ${check.error}`);reports[state]=cli('render').text;writeFileSync(join(directory,`${state}.json`),check.text);};
capture('pending',1);
const record=(gate:string,result:object)=>{writeFileSync(join(root,'.context/result.json'),JSON.stringify(result));return cli('record','--gate',gate,'--executor','fixture-inline','--mode','inline','--input','.context/result.json');};
if(record('correctness',{reviewer:'correctness',status:'APPROVED',findings:[]}).code!==2)throw Error('Malformed result accepted');capture('error',2);
const finding={id:'fixture-blocker',title:'Synthetic blocking finding',severity:'P1',file:'README.md',line:1,category:'correctness',why_it_matters:'Synthetic visual fixture, not a real review result.',autofix_class:'manual',suggested_fix:null,pre_existing:false,confidence:0.9};
if(record('correctness',{reviewer:'correctness',status:'APPROVED',findings:[finding]}).code)throw Error('Fixture record failed');capture('needs-changes',2);
for(const gate of plan.gates){if(!gate.applicable)continue;const r=record(gate.id,{reviewer:gate.id,status:'APPROVED',findings:[],sufficiency:'Synthetic output fixture: no live reviewer. Wrapping and literal content: <img src=x onerror=alert(1)> | [link](https://example.invalid) ![image](https://example.invalid/a.png).'});if(r.code)throw Error(r.error);}
capture('passed',0);
if(record('correctness',{reviewer:'correctness',status:'CONCERNS',findings:[{...finding,severity:'P2'}],sufficiency:'Synthetic non-blocking notes fixture; no live review.'}).code)throw Error('Notes fixture failed');capture('notes',0);
writeFileSync(join(root,'freshness-probe.txt'),'Transient untracked change\n');try{capture('stale',3)}finally{unlinkSync(join(root,'freshness-probe.txt'));}
reports['actual-inline-receipts']=readFileSync('.context/review-passed.md','utf8');
const app=createRequire(resolve('docs-site/package.json'));const blume=createRequire(app.resolve('blume/package.json'));const {marked}=await import(blume.resolve('marked'));
for(const [name,source]of Object.entries(reports)){
 writeFileSync(join(directory,`${name}.md`),source);
 const html=`<!doctype html><html lang="en"><meta charset="utf-8"><title>Review gate Markdown output</title><style>body{font:14px/1.5 system-ui;color:#20252c;background:#fff;margin:24px;max-width:1300px}aside{font-size:12px;color:#57606a;margin-bottom:20px}h2{font-size:24px;margin:0 0 12px}p{overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;table-layout:fixed}th,td{border:1px solid #d0d7de;padding:8px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#f6f8fa}th:nth-child(1){width:17%}th:nth-child(2){width:18%}th:nth-child(3){width:14%}tbody tr:nth-child(even){background:#fafbfc}</style><aside>New view — local Markdown preview, not hosted GitHub UI.<br>Candidate 7965c55f324b; baseline 61d68abd5f06 has no review-gate report.<br>${name==='actual-inline-receipts'?'Actual current inline receipts.':'Synthetic consumer / '+name+' state. No live reviewers.'}</aside>${await marked.parse(source,{gfm:true})}</html>`;
 writeFileSync(join(directory,`${name}.html`),html);
}
console.log(JSON.stringify({states:Object.keys(reports),candidate:'7965c55f324b59b34f6bb4d8cec07e5e6df7de41'}));
