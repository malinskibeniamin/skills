# Affected surfaces and visual evidence

Baseline: 9864d87590b3c59889c2cf130286e135af341db5.
Candidate: 0428e3a3bfbe374a11dfc3aa7dd5422fb2d4395c.

| Surface / state | Verification | Capture |
|---|---|---|
| New CLI help and check / passed | Real commands on archived base and current candidate; same flow, Chromium 1280x720, ttyd browser terminal, 15px monospace, en-US | before/after video and terminal PNGs |
| New Markdown gate report / passed, skipped, pending, invalid/error, stale, needs changes, notes | Real CLI render; existing 17 public-seam tests; Playwright screenshot assertions at 1360px and 640px | Explicit New view; base had no report command; report PNGs |
| Hook messages / malformed enums, reasoned skip, contradictory approval | Actual hook invocation in existing Bun regression tests, 620-test hook suite | Output evidence, not a graphical interaction; CLI video is primary terminal capture |
| Optional readiness JSON / not-configured, missing, mismatched, passed | Existing full-send-check public CLI tests | Machine-readable API; no separate layout |
| README, GLOSSARY, workflow references and review schema | Source Markdown and docs checks; no canonical SKILL changes, generated skill pages unchanged | No custom renderer changed; report renderer captures cover new table formatting |

No application routes, themes, user roles, forms, focus styling, responsive components or loading animations changed. Terminal and report use keyboard flow; not an interactive browser application. Narrow report layout tested for wrapping. No fixture is presented as historical product UI. Output status fixtures are labeled synthetic consumers; current passing report uses actual inline receipts. Browser terminal uses localhost only and is closed after evidence collection. Video is actual keystrokes and command execution, not animation of screenshots. No speed, defect-detection, independence, human-approval or merge-readiness claim.

Snapshot updates are limited to these newly added disposable evidence cases. Existing functional source tests remain committed; evidence tests/snapshots are included in the attached evidence archive rather than adding a new runtime dependency or CI platform to this PR.

## Rebase scope

All three source patches are identical to the previously reviewed candidate. Main's
new caller-first, structural-probe and stronger verification guidance remains intact.
Fresh report screenshots update candidate/base/input headers; actual receipt text is
shortened to current evidence. Native hook and adversarial reviewer remain main-owned.
New CLI freshness probe confirms stale exit 3 and recovery before recording. Fourteen
screenshot cases pass normally after inspecting updates. Terminal capture and video use
these exact revisions. No masks, tolerances or production guards were relaxed.
