# Review gate rebase evidence

Candidate: 0428e3a3bfbe374a11dfc3aa7dd5422fb2d4395c
Base: 9864d87590b3c59889c2cf130286e135af341db5

All three patches are unchanged by this rebase (range-diff =). Incoming caller-first,
structural-probe, type-evidence and verification guidance is preserved. The native
jq-only hook and adversarial reviewer stay main-owned; gate receipts reuse the version 1
contract. No new source branch, PR, scheduler, agents or production-service change.

Fresh checks: 217 Bun tests (17 gate cases), lint:fix, types, format, docs, 339 current
translations, three generation checks, 38 native reviewer-contract and 24 hook evals.
Earlier RED/GREEN logs document the version and critical-check reduction regressions.
Earlier 620 hook checks / 4 existing skips and 29 video evals apply to byte-identical
code/fixtures; they were not rerun during this bounded pass. Hosted CI is a snapshot,
not an assumed green result or merge-readiness claim.

Inventory covers affected surfaces. Terminal PNGs and the composed video run actual
help/check commands on these exact revisions with the same flow and settings. Report
HTML is a local Markdown preview, not hosted GitHub UI. Synthetic states are labeled;
actual-inline-receipts contains fresh inline evidence, nine passes and one reasoned
performance skip. All 14 screenshot cases pass normally after inspecting updates.
Ten rows/four columns, literal hostile text, and no horizontal overflow are asserted.
No styles, masks, tolerances or guards were relaxed. Revision/header metadata changes
are separated from shortened actual receipt text in snapshot-diff-review.json.

Replay: bunx --no-install playwright test --config
.context/rebase-latest-evidence/playwright.config.ts from the matching checkout.
The editable architecture diagram is included. No live review agents, independent model
trial, hosted playback or human approval is claimed. Logs and JSON redact local paths;
no private research attachments, credentials or account usage are included.
