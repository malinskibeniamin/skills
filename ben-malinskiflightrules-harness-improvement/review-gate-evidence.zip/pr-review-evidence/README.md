# Review-gate publication evidence

Candidate: aac1b5c4574ab4c4ae40ee4c46664a306b51deb0
Base: 0222951c3bab97050a0b8301d0b14f37fea9cc83

- `inventory.md`: complete affected-surface inventory, applicability and coverage.
- `before.png` / `after.png`: actual shell commands, not a simulated terminal.
- `flow.txt`: matched browser-terminal flow used by scripts/pr-video.sh record.
- `snapshots/`: 14 deliberately added snapshots of actual CLI-emitted Markdown, using a local renderer. Synthetic consumer states are labeled; actual-inline-receipts uses the current real plan. These are not screenshots of hosted GitHub.
- `visual.spec.ts`, `playwright.config.ts`, HTML captures and `visual-green.log`: screenshot assertion evidence (7 states x 2 widths); no snapshot-update flag on the final passing run. Extract this directory as `.context/pr-review-evidence/` in the matching checkout and run `bunx --no-install playwright test --config .context/pr-review-evidence/playwright.config.ts --max-failures=3` to replay the captured-output render checks. Fresh CLI behavior is covered by the committed `scripts/review-gates.test.ts` public-seam tests.
- `visual-red.log`: missing baseline failures plus an initial overstrict assertion rejecting ordinary GFM URL autolinks. The corrected assertion permits visible HTTPS autolinks while rejecting images, scripts, event handlers and disguised link labels. No source escaping was weakened.
- `architecture.excalidraw` / `architecture.png`: editable original before/after workflow sketch, derived from the two revisions, officially rendered and inspected. Not execution proof.
- Sanitized test/check logs: local verification on the candidate.

The final visual run passed all 14 cases after individual inspection. Narrow text wraps without horizontal overflow. No product runtime dependency or generated skill-page change was added for this disposable publication evidence. Agent execution, hosted GitHub rendering and reviewer playback were not exercised. HyperFrames usage query returned unknown; no usage/cost claim is made.
