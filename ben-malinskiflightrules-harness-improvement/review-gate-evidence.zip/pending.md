<!-- harness-review:start -->
## Review gates

Review status: pending

Candidate: 03cf91fd10736aa9bbf06c9dec2f5b9def17863d; base: 03cf91fd10736aa9bbf06c9dec2f5b9def17863d.
Review input: e1b17d0e6b2ca030d096afde03b5f926570ee75fc9d36ef0ac59291f5e8662b9 (full diff plus captured working changes).

| Gate | Executor | Status | Reason / evidence |
|---|---|---|---|
| Correctness | Not run | ⏳ Not run | Required on every change |
| Value and claims | Not run | ⏳ Not run | Required on every change |
| Test integrity | Not run | ⏳ Not run | Semantic applicability: New public-seam regression and integration tests |
| Security and recovery | Not run | ⏳ Not run | Semantic applicability: Untrusted reviewer JSON, staging paths, immutable inputs, safe report projection and atomic recovery |
| Contracts and architecture | Not run | ⏳ Not run | Semantic applicability: One canonical findings contract now feeds hooks and candidate-bound gate records |
| Surface review | Not run | ⏳ Not run | Semantic applicability: New CLI output and rendered PR table with pending, error and stale states |
| Dependencies and licenses | Not run | ⏳ Not run | Semantic applicability: Package scripts changed; verify no dependency or license churn |
| Documentation | Not run | ⏳ Not run | Path signal: README.md |
| Performance | Not run | ➖ Skipped | Semantic applicability: No speedup, throughput or resource-saving claim; no benchmark or application hot path changed |
| Operations | Not run | ⏳ Not run | Semantic applicability: Review collection and optional hosted-readiness behavior changed |

Agent and inline results are not human approval or merge authorization.
<!-- harness-review:end -->
